Project Title: ATM Simulation using Java Exception Handling
Submitted by: Anirudh Chhamalwan
Description: 
    - User login authentication with exception handling.
    - Deposit, Withdrawal, and Balance Check functionalities.
    - Proper exception messages on invalid operations.

How to Run:
    1. Compile the Java file using: javac BankAccount.java
    2. Run the program using: java BankAccount
